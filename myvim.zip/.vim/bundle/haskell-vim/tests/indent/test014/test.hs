foo :: Monad m
