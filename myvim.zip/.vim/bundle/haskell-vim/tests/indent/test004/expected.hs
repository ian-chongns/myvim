foo =
  { field = bar "("
  , quux = ""
  }
