foo =
  { field = bar "("
  }
