data Test = Test
  { x :: {-# UNPACK #-} !Int
  , y :: Int
  }
