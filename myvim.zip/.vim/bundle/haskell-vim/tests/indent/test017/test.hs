where countUntilClosed (x:xs)
