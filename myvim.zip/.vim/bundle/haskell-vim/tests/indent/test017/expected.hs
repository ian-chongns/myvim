where countUntilClosed (x:xs)
        | x
