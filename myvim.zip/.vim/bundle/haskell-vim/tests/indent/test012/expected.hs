add2 x = let y = 1
             z = 1
          in = x + y + z
