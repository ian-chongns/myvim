 where
   foo :: Monad m
       => Functor m
       => MonadIO m
       -> Int
