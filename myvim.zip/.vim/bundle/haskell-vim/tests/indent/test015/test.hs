f x = y
where
y = 2 * x
